<!--  <form role="search" method="get" class="woocommerce-product-search" action="https://lipetskmarkt.ru/">
	<div class="input-group">
<label class="screen-reader-text" for="woocommerce-product-search-field-0">Искать:</label>
	<input type="search" id="woocommerce-product-search-field-0" class="form-control" placeholder="Что вы хотите найти?" value="" name="s">
<span class="input-group-btn btn-default ">
	<button type="submit"><i class="fa fa-search"></i> </button>
	<input type="hidden" name="post_type" value="product">
</span>
</div>
</form>
--><center>
Заказ еды по телефону: <br>
<h3>8-800-000-00-00</h3>
</center>