=================
Shopress THEME
=================

Copyright (c) 2017 by ThemeICY

This Theme is distributed under the terms of the GNU GPL.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

===========
ABOUT THEME
=========== 
Shopress is Responsive, Mulshopress-Purpose, HTML5 / CSS3 Theme for (Desktop, tablet, mobile phone�)
shopress is Created with Twitter Bootstrap 3.3.2 Framework. shopress is a great design idea for
website of Creative shopress,ecommerce, Corporate, Corporation, Company Profile, Personal Portfolio, and more � 
Create Outstanding Website or Blog in Minutes!. Awesome Design, Unique Concepts, shopress has static and fixed header feature. it�s developed with lots of care and love. 

Theme has two, three, four footer layout feature.We focused on usability across various
devices, starting with smart phones.it is compatible with various devices. shopress is a
Cross-Browser Compatible theme that works on All leading web browsers. shopress is easy to use and 
user friendly theme. 
Powerful but simple shopress theme content customized through customizer. to make your site attractive it has two 
widget sections first for �sidebar widget section� and second for �Footer widget section� . 

To make your website in two column use sidebar widget section. to set custom menu in header set primary location. we added social media links to added your social links.It boasts of beautifully designed page sections , Home, Blog and Default Page Template(page with right sidebar), Page Full-Width, Page Left Sidebar. shopress theme has more advanced feature to make your site awesome like: it has header top bar dark & lite color feature. you can also changed header color dark and lite styling. Theme compatible with woocommerce. shopress is a fully woocommerce compitable theme. shopress is translation ready theme with WPML compatible & Many More�.

This theme is compatible with Wordpress Version 4.5.2  and above and it supports the new theme customization API (https://codex.wordpress.org/Theme_Customization_API).

Supported browsers: Firefox, Opera, Chrome, Safari and IE10+ (Some css3 styles like shadows, rounder corners and 2D transform are not supported by IE8 and below).

/***** BUNDELED CSS ***/
============================================
This theme uses Underscores
============================================
 * shopress is based on Underscores. All the files in the theme package are from Underscores, unless stated otherwise.
 * Copyright: Automattic, automattic.com
 * Source: http://underscores.me/
 * License: GPLv2
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html

============================================
This theme uses Font Awesome for the theme icons
============================================
 * Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
 * Source: http://fontawesome.io
 * License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
======================================
This theme uses Bootstrap as a design tool
======================================
 * Bootstrap (http://getbootstrap.com/)
 * Copyright (c) 2011-2014 Twitter, Inc
 * Licensed under https://github.com/twbs/bootstrap/blob/master/LICENSE
======================================

======================================

/***** BUNDELED JS ***/
This theme uses Owl Carousel
======================================
 * Licensed under https://github.com/OwlFonk/OwlCarousel
======================================

This theme uses vadikom/smartmenus
======================================
 * Licensed under https://github.com/vadikom/smartmenus
======================================

/**** Images Source *****/

============================================
All images use Pixabay
============================================

/***** Screenshot Image CCO by Unsplash  *****/
https://pixabay.com/en/clothing-store-shop-boutique-984396/

/***** Bredcrumb Image CCO by Unsplash  *****/
https://pixabay.com/en/clothing-store-shop-boutique-984396/

/***** Blog image CCO by Pexels / 9191 images *****/
https://pixabay.com/en/cap-fashion-man-model-person-sky-1845041/

/***** product images *****/

The images were obtained from the Sample Test Data provided by WooCommerce Plugin. They are under GPL License.

Source: https://wordpress.org/plugins/woocommerce/
    https://github.com/woothemes/woocommerce/tree/master/dummy-data

License:
    https://github.com/woothemes/woocommerce/blob/master/license.txt



========================================================================================	
--- Version 0.1 ----
1. Relesed 

--- Version 0.2 ----
1. Fixed theme review issue.

--- Version 0.3 ----
1. Fixed theme review issue.

--- Version 0.4 ----
1. Fixed theme review issue.

--- Version 0.5 ----
1. Fixed theme review issue.

--- Version 0.6 ----
1. Update screnshot image.

--- Version 0.7 ----
1. Fixed styling issue.

--- Version 0.8 ----
1. Update social icon & copyright default value.

--- Version 0.9 ----
1. Added Calltoaction section.
2. Update screenshot image.