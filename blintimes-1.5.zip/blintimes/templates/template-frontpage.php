<?php
/**
 * Template Name: Home Page
 */ 
		 get_header(); 
		
		//=========== Get Home Slider ===========//
		//echo do_shortcode( '[smartslider3 slider=1]');
		
		//=========== Get Call to action ===========//
		get_template_part('sections/home','calltoaction');

		//=========== Get Index product ===========//		
		get_template_part('sections/home', 'product');	
		
		//=========== Get Index News ===========//
		get_template_part('sections/home', 'blog');			
					

get_footer(); 
?>