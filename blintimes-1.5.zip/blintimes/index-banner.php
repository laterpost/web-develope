<?php
/**
 * @package shopress
 */ ?>
<?php //echo do_shortcode( '[smartslider3 slider=1]'); ?>

<div class="clearfix"></div>